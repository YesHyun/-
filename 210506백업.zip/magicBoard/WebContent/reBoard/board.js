function check_ok(){
//	if(document.form.b_name.value == ""){}		// 값이 null값인 경우
	if(document.form.b_name.value.length == 0){	// 값의 길이가 0인경우 결국 둘다 같은말
		alert("이름을 입력하세요."); 	// 팝업창 열기 alert 
		form.b_name.focus();	// 아이디가 안써져있을때 해당 박스로 커서 이동 
		return;
	}
	if(document.form.b_title.value.length == 0){	// 값의 길이가 0인경우 결국 둘다 같은말
		alert("제목을 입력하세요."); 	// 팝업창 열기 alert 
		form.b_title.focus();	// 아이디가 안써져있을때 해당 박스로 커서 이동 
		return;
	}
	if(document.form.b_content.value.length == 0){	// 값의 길이가 0인경우 결국 둘다 같은말
		alert("내용을 입력하세요."); 	// 팝업창 열기 alert 
		form.b_content.focus();	// 아이디가 안써져있을때 해당 박스로 커서 이동 
		return;
	}
	
	if(document.form.b_pwd.value.length == 0){	
		alert("비밀번호를 입력하세요."); 	
		form.b_pwd.focus();	 
		return;
	}
	
	document.form.submit();
}
function delete_ok(){
	if(document.form.b_pwd.value.length == 0){
		alert("비밀번호를 입력하세요.");
		form.b_pwd.focus;
		return;
	}
	document.form.submit();
}
