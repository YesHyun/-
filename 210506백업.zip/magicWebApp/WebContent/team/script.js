function check_ok1(){
	if(document.reg_frm1.id.value.length == 0){	// 값의 길이가 0인경우 결국 둘다 같은말
		alert("아이디를 써주세요."); 	// 팝업창 열기 alert 
		reg_frm1.id.focus();	// 아이디가 안써져있을때 해당 박스로 커서 이동 
		return;
	}
	if(document.reg_frm1.id.value.length < 4){
		alert("아이디를 4글자 이상이어야 합니다.");
		reg_frm1.id.focus();
		return;
	}
	if(document.reg_frm1.name.value.length == 0){
		alert("이름을 써주세요.");
		reg_frm1.name.focus();
		return;
	}
	if(document.reg_frm1.pass.value.length == 0){
		alert("패스워드는 반드시 입력해야 합니다.");
		reg_frm1.pass.focus();
		return;
	}
	if(document.reg_frm1.pass.value.length != document.reg_frm.pass2.value.length){
		alert("패스워드가 일치하지 않습니다.");
		reg_frm1.pass2.focus();
		return;
	}

	if(document.reg_frm1.email1.value.length == 0){
		alert("이메일을 써주세요.");
		reg_frm1.email1.focus();
		return;
	}
	document.reg_frm1.submit();
}