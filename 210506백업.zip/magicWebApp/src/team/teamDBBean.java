package team;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import magic.member.MemberBean;
import myUtil.HanConv;

public class teamDBBean {
	private static teamDBBean instance = new teamDBBean();
	
	public static teamDBBean gesInstance() {
		return instance;
	}
	public Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	public int insertMember(teamBean member) throws Exception{
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "insert into memberT2 values(?,?,?,?,?,?,?,?)";
		int re=-1;
		
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, member.getId());
			pstmt.setString(2, HanConv.toKor(member.getName()));
			pstmt.setString(3, member.getPass());
			pstmt.setString(4, HanConv.toKor(member.getGender()));
			pstmt.setString(5, member.getBirth_yy());
			pstmt.setString(6, member.getBirth_mm());
			pstmt.setString(7, member.getBirth_dd());
			pstmt.setString(8, member.getEmail1());
			
			pstmt.executeUpdate();
			re=1;
			pstmt.close();
			con.close();
			System.out.println("�߰� ����");
		} catch (Exception e) {
			System.out.println("�߰� ����");
			e.printStackTrace();
			re=-1;
		}
		return re;
	}
	public int confirmID(String id) throws Exception{
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select id from memberT2 where id = ?";
		
		int re = -1;
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			// �ߺ����� Ȯ���ϱ� if(rs.next()){ �ؼ� ������ ������ 1�� ��ȯ���ش� �׷� registerOk.jsp ���� 1�� �޾����� �ߺ��Ǵ� ���̵� �����մϴ� ��� ���
			if(rs.next()) {
				re = 1;
			}else {
				re = -1;
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return re;
	}
	public int userCheck(String id, String pass) throws Exception{
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql="select pass from memberT2 where id=?"; 
		String db_pass;
		int re=-1;
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				db_pass = rs.getString("pass");
				if(db_pass.equals(pass)) {
					re=1;
				}else { // ��й�ȣ�� Ʋ�����
					re=0;
				}
			}else { // ���̵� Ʋ�����
				re=-1;
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return re;
	}
	
	public teamBean getMember(String id) throws Exception{
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql="select * from memberT2 where id=?"; 
		teamBean member = null;
		
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				member = new teamBean();
				member.setId(rs.getString("id"));
				member.setName(rs.getString("name"));
				member.setPass(rs.getString("pass"));
				member.setGender(rs.getString("gender"));
				member.setEmail1(rs.getString("email1"));
				member.setBirth_yy(rs.getString("birth_yy"));
				member.setBirth_mm(rs.getString("birth_mm"));
				member.setEmail1(rs.getString("email1"));
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return member;
	
	}
	public int updateMember(teamBean member)throws Exception{
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql="update memberT2 set pass=?, email1=?, where id=?"; 
		int re=-1;
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, member.getPass());
			pstmt.setString(2, member.getEmail1());
			pstmt.setString(4, member.getId());
			re=pstmt.executeUpdate();
			
			pstmt.close();
			con.close();
			System.out.println("���� ����");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("���� ����");
		}
		return re;
	}
}















																									
